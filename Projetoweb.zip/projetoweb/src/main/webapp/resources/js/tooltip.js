$(document).ready(function() {
	$('[data-tooltip="tooltip"]').tooltip()
});