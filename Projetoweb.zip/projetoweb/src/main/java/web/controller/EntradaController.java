package web.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import web.dao.ItemDao;
import web.dao.ResponsavelDao;
import web.dao.ServidorDao;
import web.dao.SolicitacaoDao;
import web.dao.EntradaItemDao;
import web.modelo.Item;
import web.modelo.Responsavel;
import web.modelo.Servidor;
import web.modelo.EntradaItem;
import web.modelo.EntradaItens;

@Transactional
@Controller
@RequestMapping("/entrada")
public class EntradaController {

	private EntradaItens itens_qnt;
	private Responsavel responsavel;
	private Item item;
	private int nova_qnt;
	private List<Item> lista_itens;
	private List<EntradaItens> lista_itens_qnt;
	private List<EntradaItem> lista_entrada_itens;

	@Autowired
	ResponsavelDao dao_responsavel;

	@Autowired
	ItemDao dao_item;

	@Autowired
	EntradaItemDao dao_entrada_item;

	@RequestMapping("/novo")
	public String entrada(Model model) {
		this.lista_itens = dao_item.lista();
		model.addAttribute("itens", this.lista_itens);
		return "entrada/novo";
	}

	@RequestMapping(value = "/adiciona_itens", method = RequestMethod.POST)
	public String adicionaItens(HttpServletRequest request, HttpServletResponse response, Model model)
			throws Exception {

		this.lista_itens = dao_item.lista();
		this.lista_itens_qnt = new ArrayList<EntradaItens>();

		for (Item item : this.lista_itens) {
			if (request.getParameter(item.getId() + "_qnt") != null) {
				if (!request.getParameter(item.getId() + "_qnt").equals("")) {
					if (Integer.parseInt(request.getParameter(item.getId() + "_qnt")) > 0) {
						this.itens_qnt = new EntradaItens();
						this.itens_qnt.setId_item(item.getId());
						this.itens_qnt.setNome(item.getNome());
						this.itens_qnt.setMarca(item.getMarca());
						this.itens_qnt.setQnt(Integer.parseInt(request.getParameter(item.getId() + "_qnt")));
						this.lista_itens_qnt.add(this.itens_qnt);
					}
				}
			}
		}

		if (!this.lista_itens_qnt.isEmpty()) {
			model.addAttribute("itens", this.lista_itens_qnt);
			return "entrada/confirmacao";
		} else {
			return "redirect:novo";
		}

	}

	@RequestMapping("/adiciona")
	public String adiciona() {

		// Pega o último responsavel cadastrado
		this.responsavel = dao_responsavel.buscaPorId(1L);

		// Adiciona os itens de EntradaItem
		for (EntradaItens item : this.lista_itens_qnt) {
			this.dao_entrada_item.adiciona(this.responsavel.getId(), item.getId_item(), item.getQnt());
		}

		return "redirect:lista";
	}

	@RequestMapping("/lista")
	public String lista(Model model) {
		this.lista_entrada_itens = dao_entrada_item.lista();
		model.addAttribute("solicitacoes", this.lista_solicitacoes);
		return "responsavel/lista";
	}

	@RequestMapping("/exibe")
	public String exibe(Long id, Model model) {
		model.addAttribute("responsavel", dao.buscaPorId(id));
		model.addAttribute("itens_solicitacao", dao_entrada_item.buscaItensSolicitacaoPorSolicitacaoId(id));
		return "responsavel/exibe";
	}

	@RequestMapping("/aprovar")
	public String aprovar(Long id, Model model) {

		if (dao.buscaPorId(id).getStatus().equals("Solicitado")) {

			// Lista de itens da solicitação
			this.lista_entrada_itens = dao_entrada_item.buscaItensSolicitacaoPorSolicitacaoId(id);

			// Altera a quantidade de todos os itens da Solicitação
			for (EntradaItem solicitacao_item : this.lista_entrada_itens) {
				this.item = dao_item.buscaPorId(solicitacao_item.getItem().getId());
				this.nova_qnt = this.item.getQnt() - solicitacao_item.getQnt();
				dao_item.atualizaQnt(this.item.getId(), this.nova_qnt);
			}

			// Pega o último responsável cadastrado
			this.responsavel = dao_responsavel.buscaPorId(1L);

			// Alterar o Status da Solicitação para Aprovado
			dao.aprovaSolicitacao(id, this.responsavel.getId());

		}

		return "redirect:exibe?id=" + id;
	}

	@RequestMapping("/rejeitar")
	public String rejeitar(Long id, Model model) {

		if (dao.buscaPorId(id).getStatus().equals("Solicitado")) {
			// Pega o último responsável cadastrado
			this.responsavel = dao_responsavel.buscaPorId(1L);

			// Alterar o Status da Solicitação para Aprovado
			dao.rejeitaSolicitacao(id, this.responsavel.getId());
		}

		return "redirect:exibe?id=" + id;
	}
}