package web.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import web.modelo.SolicitacaoItem;

@Repository
public class SolicitacaoItemDao {

	@PersistenceContext
	private EntityManager manager;

	public void adiciona(Long solicitacao_id, Long item_id, int qnt) {
		manager.createNativeQuery(
				"insert into SolicitacaoItem (solicitacao_id, item_id, qnt) values (:solicitacao_id, :item_id, :qnt)")
				.setParameter("solicitacao_id", solicitacao_id).setParameter("item_id", item_id)
				.setParameter("qnt", qnt).executeUpdate();
	}

	public List<SolicitacaoItem> buscaItensSolicitacaoPorSolicitacaoId(Long solicitacao_id) {
		return manager.createQuery("select s from SolicitacaoItem s where s.solicitacao.id = :solicitacao_id",
				SolicitacaoItem.class).setParameter("solicitacao_id", solicitacao_id).getResultList();
	}

}
