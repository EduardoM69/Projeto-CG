package web.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import web.modelo.Responsavel;

@Repository
public class ResponsavelDao {

	@PersistenceContext
	private EntityManager manager;

	public void adiciona(Responsavel responsavel) {
		manager.persist(responsavel);
	}

	public void altera(Responsavel responsavel) {
		manager.merge(responsavel);
	}

	public List<Responsavel> lista() {
		return manager.createQuery("select c from Responsavel c order by c.id desc", Responsavel.class).getResultList();
	}

	public List<Responsavel> buscaPorNome(String nome) {
		return manager.createQuery("select c from Responsavel c where c.nome = :nome", Responsavel.class).setParameter("nome", nome)
				.getResultList();
	}

	public String buscaNomePorId(Long id) {
		return manager.createQuery("select c.nome from Responsavel c where c.id = :id", String.class).setParameter("id", id)
				.getSingleResult();
	}

	public Responsavel buscaPorId(Long id) {
		return manager.find(Responsavel.class, id);
	}

	public void remove(Long id) {
		manager.createQuery("delete from Responsavel c where c.id = :id").setParameter("id", id).executeUpdate();
	}

}