package web.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import web.modelo.EntradaItem;

@Repository
public class EntradaItemDao {

	@PersistenceContext
	private EntityManager manager;

	public void adiciona(Long responsavel_id, Long item_id, int qnt) {
		manager.createNativeQuery(
				"insert into EntradaItem (responsavel_id, item_id, qnt) values (:responsavel_id, :item_id, :qnt)")
				.setParameter("responsavel_id", responsavel_id).setParameter("item_id", item_id)
				.setParameter("qnt", qnt).executeUpdate();
	}

	public List<EntradaItem> buscaItensSolicitacaoPorSolicitacaoId(Long responsavel_id) {
		return manager.createQuery("select s from EntradaItem s where s.responsavel.id = :responsavel_id",
				EntradaItem.class).setParameter("responsavel_id", responsavel_id).getResultList();
	}
}
