package web.modelo;

import java.io.Serializable;

public class EntradaItemPK implements Serializable {

	private Long responsavel;

	private Long item;

	private int qnt;

	public EntradaItemPK(Long responsavel, Long item, int qnt) {
		super();
		this.responsavel = responsavel;
		this.item = item;
		this.qnt = qnt;
	}

	public EntradaItemPK() {
	}

	public Long getResponsavel() {
		return responsavel;
	}

	public void setResponsavel(Long responsavel) {
		this.responsavel = responsavel;
	}

	public Long getItem() {
		return item;
	}

	public void setItem(Long item) {
		this.item = item;
	}

	public int getQnt() {
		return qnt;
	}

	public void setQnt(int qnt) {
		this.qnt = qnt;
	}

}
