# projetoweb

Projeto inicial baseado na apostila de Programação WEB - Capítulo 11.

Projeto ja contem todas as bibliotecas no maven e os arquivos xml configurados.
