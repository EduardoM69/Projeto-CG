# Disciplina ministrada de Programação Web com Spring Framework

Projeto inicial de baseado na apostila da Caelum de Programação WEB - Capítulo 11.

Projeto ja contem todas as bibliotecas no maven e os arquivos xml configurados.
